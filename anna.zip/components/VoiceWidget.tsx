
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { VoiceSession } from '../services/liveApiService';
import VoiceIndicator from './VoiceIndicator';
import { ConnectionStatus } from '../types';

const VoiceWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.DISCONNECTED);
  const [transcript, setTranscript] = useState<{ text: string, role: 'user' | 'agent' }[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const sessionRef = useRef<VoiceSession | null>(null);
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [transcript, isOpen]);

  const handleTranscript = useCallback((text: string, role: 'user' | 'agent') => {
    setTranscript(prev => [...prev, { text, role }]);
  }, []);

  const handleError = useCallback((error: string) => {
    setErrorMessage(error);
    setStatus(ConnectionStatus.ERROR);
  }, []);

  const handleStatusChange = useCallback((connected: boolean) => {
    setStatus(connected ? ConnectionStatus.CONNECTED : ConnectionStatus.DISCONNECTED);
  }, []);

  const toggleSession = async () => {
    if (status === ConnectionStatus.CONNECTED || status === ConnectionStatus.CONNECTING) {
      sessionRef.current?.stop();
      sessionRef.current = null;
      setStatus(ConnectionStatus.DISCONNECTED);
    } else {
      setErrorMessage(null);
      setStatus(ConnectionStatus.CONNECTING);
      const session = new VoiceSession(handleTranscript, handleError, handleStatusChange);
      sessionRef.current = session;
      await session.start();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[2147483647] flex flex-col items-end pointer-events-none font-sans">
      {/* Chat Window */}
      {isOpen && (
        <div className="bg-white w-[350px] md:w-[400px] rounded-3xl shadow-[0_20px_70px_rgba(0,0,0,0.25)] overflow-hidden border border-gray-100 flex flex-col mb-4 pointer-events-auto animate-in slide-in-from-bottom-6 duration-500 ease-out">
          <div className="p-6 bg-blue-600 text-white flex justify-between items-center relative overflow-hidden">
            {/* Decorative background circle */}
            <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full"></div>
            
            <div className="flex items-center space-x-4 z-10">
              <div className="relative">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-inner">
                   <span className="text-2xl font-black text-blue-600">A</span>
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
              </div>
              <div>
                <h3 className="font-bold text-xl leading-tight tracking-tight">Anna</h3>
                <p className="text-blue-100 text-[10px] uppercase tracking-widest font-bold opacity-80">Expert Career AI</p>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)} 
              className="hover:bg-blue-700/50 p-2 rounded-xl transition-all active:scale-90 z-10"
              aria-label="Close Chat"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>

          <div className="flex-1 min-h-[300px] max-h-[450px] overflow-y-auto p-6 bg-[#fcfdfe] flex flex-col space-y-4">
            {transcript.length === 0 && (
              <div className="text-center py-6 px-4 animate-in fade-in zoom-in duration-700">
                <div className="mb-4 inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-50 text-blue-500">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                </div>
                <p className="text-base text-gray-800 font-medium mb-2">"Welcome to The Dream Job Consultant!"</p>
                <p className="text-sm text-gray-500 leading-relaxed">
                  I'm Anna. Click below to chat about your career goals, resume, or reverse recruiting.
                </p>
              </div>
            )}
            {transcript.map((item, idx) => (
              <div key={idx} className={`flex ${item.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
                <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
                  item.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-none' 
                    : 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
                }`}>
                  {item.text}
                </div>
              </div>
            ))}
            <div ref={transcriptEndRef} />
          </div>

          <div className="p-8 bg-white border-t flex flex-col items-center space-y-6">
            <VoiceIndicator 
              isActive={status === ConnectionStatus.CONNECTED} 
              status={status === ConnectionStatus.CONNECTED ? 'connected' : status === ConnectionStatus.CONNECTING ? 'connecting' : status === ConnectionStatus.ERROR ? 'error' : 'idle'}
            />
            
            <button
              onClick={toggleSession}
              disabled={status === ConnectionStatus.CONNECTING}
              className={`w-full py-4 rounded-2xl font-bold text-lg transition-all shadow-xl active:scale-95 transform ${
                status === ConnectionStatus.CONNECTED 
                  ? 'bg-red-500 hover:bg-red-600 text-white shadow-red-100' 
                  : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-100 hover:-translate-y-0.5'
              } disabled:opacity-50`}
            >
              {status === ConnectionStatus.CONNECTED ? 'Stop Speaking' : 
               status === ConnectionStatus.CONNECTING ? 'Connecting...' : 'Start Audio Session'}
            </button>
            
            {errorMessage && (
              <div className="bg-red-50 text-red-600 p-3 rounded-xl w-full text-center border border-red-100">
                 <p className="text-xs font-bold">{errorMessage}</p>
              </div>
            )}
            
            <div className="flex items-center space-x-2 text-[10px] text-gray-400 uppercase tracking-widest font-bold">
              <span className="opacity-50">Authorized by</span>
              <span className="text-blue-500">The Dream Job Consultant</span>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`pointer-events-auto w-16 h-16 rounded-full flex items-center justify-center shadow-[0_15px_45px_rgba(37,99,235,0.4)] transition-all duration-500 transform ${
          isOpen ? 'bg-white text-blue-600 rotate-90 scale-90' : 'bg-blue-600 text-white hover:scale-110 hover:-translate-y-2'
        }`}
        aria-label="Toggle Anna AI"
      >
        {isOpen ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        ) : (
          <div className="relative">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-9 w-9" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
            <span className="absolute -top-1 -right-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-blue-500 border-2 border-white"></span>
            </span>
          </div>
        )}
      </button>
    </div>
  );
};

export default VoiceWidget;
