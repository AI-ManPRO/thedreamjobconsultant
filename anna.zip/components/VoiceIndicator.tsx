
import React from 'react';

interface VoiceIndicatorProps {
  isActive: boolean;
  status: 'connecting' | 'connected' | 'idle' | 'error';
}

const VoiceIndicator: React.FC<VoiceIndicatorProps> = ({ isActive, status }) => {
  return (
    <div className="relative flex items-center justify-center w-24 h-24">
      {isActive && (
        <>
          <div className="pulse-ring scale-150"></div>
          <div className="pulse-ring scale-110 opacity-50"></div>
        </>
      )}
      <div className={`z-10 w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300 ${
        status === 'connected' ? 'bg-blue-500 shadow-lg shadow-blue-200' :
        status === 'connecting' ? 'bg-amber-400' :
        status === 'error' ? 'bg-red-500' :
        'bg-gray-200'
      }`}>
        <svg xmlns="http://www.w3.org/2000/svg" className={`h-8 w-8 text-white transition-transform duration-300 ${isActive ? 'scale-125' : 'scale-100'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
        </svg>
      </div>
    </div>
  );
};

export default VoiceIndicator;
