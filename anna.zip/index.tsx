
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

/**
 * Anna Voice Agent - Self-Mounting Bootstrap
 * Designed to be dropped into www.TheDreamJobConsultant.com
 */
const mountAnnaWidget = () => {
  const CONTAINER_ID = 'anna-voice-widget-root';
  
  // Prevent multiple instances if the script is loaded twice
  if (document.getElementById(CONTAINER_ID)) return;

  // Create a shadow-like container to isolate widget from site styles
  const widgetContainer = document.createElement('div');
  widgetContainer.id = CONTAINER_ID;
  
  // Ensure the widget is always at the top level of the DOM
  document.body.appendChild(widgetContainer);

  const root = ReactDOM.createRoot(widgetContainer);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
  
  console.log('Anna Voice Agent initialized on TheDreamJobConsultant.com');
};

// Mount the widget as soon as the DOM is ready
if (document.readyState === 'complete' || document.readyState === 'interactive') {
  mountAnnaWidget();
} else {
  document.addEventListener('DOMContentLoaded', mountAnnaWidget);
}
